# Vconomics Refferal Bot

How to use :

1. git clone https://github.com/dkmpostor/vconomics/
2. cd vconomics
3. npm install
4. node index.js
5. Input refferal code
6. Done

NOTE :

If you get log INVALID_EMAIL_ADDRESS , just change email's domain on line 151 .. Search another domain from https://generator.email/

Thank you
